<!-- Footer -->

<div class="footer-container">
    <footer role="contentinfo">
      &copy; Thomas McCarten | <?php echo date("Y"); ?> | All rights reserved.
    </footer>
</div>
